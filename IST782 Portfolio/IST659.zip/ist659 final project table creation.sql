--drop data logic objects
drop procedure if exists p_customer_rating
GO

drop procedure if exists p_restaurant_coordinates
GO

--drop views
if exists(select * from sys.objects where name='v_owner_list')
	drop view v_owner_list

if exists(select * from sys.objects where name='v_restaurants_categories')
	drop view v_restaurants_categories

if exists(select * from sys.objects where name='v_restaurants_data_sources')
	drop view v_restaurants_data_sources

if exists(select * from sys.objects where name='v_restaurants_owners')
	drop view v_restaurants_owners

if exists(select * from sys.objects where name='v_restaurants_customer_ratings')
	drop view v_restaurants_customer_ratings

--down tables
if exists(select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    where CONSTRAINT_NAME='fk_websites_website_restaurant_id')
    alter table websites drop constraint fk_websites_website_restaurant_id

if exists(select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS
    where CONSTRAINT_NAME='fk_restaurants_restaurant_state')
    alter table restaurants drop constraint fk_restaurants_restaurant_state

if exists(select * from sys.objects where name='restaurants_customer_ratings')
	drop table restaurants_customer_ratings

if exists(select * from sys.objects where name='restaurants_owners')
	drop table restaurants_owners

if exists(select * from sys.objects where name='restaurants_data_sources')
	drop table restaurants_data_sources

if exists(select * from sys.objects where name='restaurants_categories')
	drop table restaurants_categories

if exists(select * from sys.objects where name='websites')
	drop table websites

if exists(select * from sys.objects where name='restaurants')
	drop table restaurants

if exists(select * from sys.objects where name='customer_ratings')
	drop table customer_ratings

if exists(select * from sys.objects where name='owners')
	drop table owners

if exists(select * from sys.objects where name='data_sources')
	drop table data_sources

if exists(select * from sys.objects where name='categories')
	drop table categories

if exists(select * from sys.objects where name='state_lookup')
	drop table state_lookup
GO

--up tables
--creating tables
create table state_lookup (
    state_abbreviation char(2) not null,
    constraint pk_state_lookup_state_abbreviation primary key(state_abbreviation)
)

create table categories (
    category_id int identity not null,
    category_name varchar(50) not NULL,
    constraint pk_categories_category_id primary key(category_id)
)

create table data_sources (
    source_id int identity not null,
    source_name varchar(50) not null,
    source_url varchar(100) not null,
    source_date_added datetime not null,
    source_date_updated datetime not NULL,
    constraint pk_sources_source_id primary key(source_id),
    constraint u_sources_source_url unique(source_url),
    constraint ck_valid_source_dates check (source_date_updated>=source_date_added)
)

create table owners (
    owner_id int IDENTITY not null,
    owner_firstname varchar(30) not null,
    owner_lastname varchar(30) not NULL,
    CONSTRAINT pk_owners_owner_id primary key(owner_id)
)

create table customer_ratings (
    customer_rating_id int identity not null,
    customer_id int not null,
    customer_rating int not NULL,
    constraint pk_ratings_customer_rating_id primary key(customer_rating_id),
    constraint ck_ratings_customer_rating check (customer_rating between 1 and 5),
)

create table restaurants (
    restaurant_id int identity not null,
    restaurant_name varchar(50) not null,
    restaurant_street_address varchar(100) not null,
    restaurant_city varchar(30) not null,
    restaurant_state_abbrevation char(2) not null,
    restaurant_zip_code char(5) not null,
    restaurant_longitude FLOAT not null,
    restaurant_latitude FLOAT not null,
    constraint pk_restaurants_restaurant_id primary key(restaurant_id),
    constraint ck_restaurants_restaurant_zip_code check (restaurant_zip_code Like '[0-9][0-9][0-9][0-9][0-9]'),
    constraint ck_restaurants_restaurant_longitude check (restaurant_longitude between -180 and 180),
    constraint ck_restaurants_restaurant_latitude check (restaurant_latitude between -90 and 90)
)

create table websites (
    website_id int identity not null,
    website_address varchar(60) not null,
    website_restaurant_id int not null,
    CONSTRAINT pk_websites_website_id primary key(website_id),
    constraint u_websites_website_address unique(website_address)
)

--bridge tables
--restaurants and categories
create table restaurants_categories (
	restaurant_id int not null foreign key references restaurants(restaurant_id),
	category_id int not null foreign key references categories(category_id),
	constraint pk_restaurants_categories_id primary key(restaurant_id, category_id)
)

--restaurants and data sources
create table restaurants_data_sources (
	restaurant_id int not null foreign key references restaurants(restaurant_id),
	source_id int not null foreign key references data_sources(source_id),
	constraint pk_restaurants_sources_id primary key(restaurant_id, source_id)
)

--restaurants and owners
create table restaurants_owners (
	restaurant_id int not null foreign key references restaurants(restaurant_id),
	owner_id int not null foreign key references owners(owner_id),
	constraint pk_restaurants_owners_id primary key(restaurant_id, owner_id)
)

--restaurants and customer ratings
create table restaurants_customer_ratings (
	restaurant_id int not null foreign key references restaurants(restaurant_id),
	customer_rating_id int not null foreign key references customer_ratings(customer_rating_id),
	constraint pk_restaurants_ratings_id primary key(restaurant_id, customer_rating_id)
)

--foreign keys
--restaurants and state lookup
alter table restaurants
    add constraint fk_restaurants_restaurant_state FOREIGN KEY (restaurant_state_abbrevation)
        REFERENCES state_lookup(state_abbreviation)

--website and restaurants 
alter table websites
    add CONSTRAINT fk_websites_website_restaurant_id foreign key (website_restaurant_id)
        REFERENCES restaurants(restaurant_id)
GO
--views

create view v_owner_list as 
    select owner_id, owner_firstname+' '+owner_lastname as owner_name
    from owners
GO

create view v_restaurants_categories as 
    select r.restaurant_id, c.category_name,
    r.restaurant_name, 
    r.restaurant_street_address,+r.restaurant_city,r.restaurant_state_abbrevation,r.restaurant_zip_code 
    from restaurants r 
    join restaurants_categories rc on r.restaurant_id = rc.restaurant_id
    join categories c on rc.category_id = c.category_id
go

create view v_restaurants_data_sources as 
    select r.restaurant_id, r.restaurant_name, ds.source_name, ds.source_url
    from restaurants r 
    join restaurants_data_sources rds on r.restaurant_id = rds.restaurant_id
    join data_sources ds on rds.source_id = ds.source_id
go

create view v_restaurants_owners as 
    select r.restaurant_id, o.owner_firstname+' '+o.owner_lastname as owner_name, r.restaurant_name, 
    r.restaurant_street_address,r.restaurant_city,r.restaurant_state_abbrevation,r.restaurant_zip_code
    from restaurants r 
    join restaurants_owners ro on r.restaurant_id = ro.restaurant_id
    join owners o on ro.owner_id = o.owner_id
go

create view v_restaurants_customer_ratings as 
    select r.restaurant_id, r.restaurant_name, 
    r.restaurant_street_address,r.restaurant_city,r.restaurant_state_abbrevation,r.restaurant_zip_code,
     cr.customer_id,
    cr.customer_rating
    from restaurants r 
    join restaurants_customer_ratings rcr on r.restaurant_id = rcr.restaurant_id
    join customer_ratings cr on rcr.customer_rating_id = cr.customer_rating_id
go    

--create data logic objects
--procedure
create procedure p_customer_rating
(
	@customer_id int,
	@customer_rating int
)
as begin
    begin TRANSACTION
    begin try
	insert into customer_ratings (customer_id, customer_rating)
	values (@customer_id, @customer_rating)
	if @customer_rating > 5 throw 50005, 'Cannot enter rating greater than 5',1 --bmwachte
    if @customer_rating < 1 throw 50006, 'Cannot enter rating less than 1',1
    return @@identity 
    COMMIT
end TRY
begin CATCH
ROLLBACK;
THROW
end CATCH
end
GO

--procedure
create procedure p_restaurant_coordinates
(
	@longitude int,
	@latitude int
)
as begin
    begin TRANSACTION
    begin try
	insert into restaurants (restaurant_longitude, restaurant_latitude)
	values (@longitude, @latitude)
	if @longitude > 280 or @longitude < -180 throw 50007, 'Invalid longitude',1 --bmwachte
    if @latitude > 90 or @latitude < -90 throw 50008, 'Invalid latitude',1
    return @@identity 
    COMMIT
end TRY
begin CATCH
ROLLBACK;
THROW
end CATCH
end
GO
