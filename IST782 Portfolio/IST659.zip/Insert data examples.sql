

INSERT into state_lookup 
    (state_abbreviation)
        VALUES
    ('NJ'),
    ('PA'),
    ('CT'),
    ('NY')
GO

insert into categories
    (category_name)
    VALUES
    ('Pizza'),
    ('Burger Restaurant'),
    ('Coffee Shop'),
    ('Ice Cream'),
    ('Chicken Restaurant'),
    ('Health Food Restaurant'),
    ('Hot Dogs'),
    ('Taco Place'),
    ('Take-Out')
GO

insert into data_sources
    (source_name,source_url,source_date_added,source_date_updated)
    VALUES
    ('google','google.com','2019-01-10','2019-01-15'),
    ('bing','bing.com','2020-01-01','2020-02-01'),
    ('foursquare','foursquare.com','2021-04-01','2021-05-01'),
    ('yellowpages','yellowpages.com','2021-01-21','2021-02-01'),
    ('facebook','facebook.com','2021-05-02','2021-05-18')
GO

insert into owners
   (owner_firstname,owner_lastname)
   VALUES
   ('Ben','Wachtel'),
   ('Dan','Brockett'),
   ('Bob','Belcher'),
   ('Mung','Daal'),
   ('Gus','Fring')
GO

insert into customer_ratings
    (customer_id,customer_rating)
    VALUES
    (10,3),
    (10,4),
    (10,2),
    (20,5),
    (30,1),
    (30,3),
    (40,5),
    (40,5),
    (50,2),
    (50,3),
    (60,3),
    (60,5),
    (70,2),
    (80,5),
    (80,5),
    (90,1),
    (90,2),
    (90,4),
    (100,4),
    (100,5)
GO

insert into restaurants
    (restaurant_name,restaurant_street_address,restaurant_city,restaurant_state_abbrevation,restaurant_zip_code,restaurant_longitude,restaurant_latitude)
    VALUES
    ('Ben''s Burgers and Hot Dogs','1 Main Street','Edison','NJ','08820',40.571833,-74.352716),
    ('Dan''s Pizza Palace','15 South Street','New Haven','CT','06511',41.318633,-72.932189),
    ('Bob''s Burgers','300 Ocean Avenue','Cape May','NJ','08204',38.937899,-74.897592),
    ('Los Pollos Hermonos','125 65th street','Philadelphia','PA','19104',39.965166,-75.201411),
    ('Mung Daal''s Healthy Eats','321 Place Avenue','Syracuse','NY','13208',43.069090,-76.147300),
    ('Retro Creamery','7 Water Drive','White Plains','NY','10601',41.031172,-73.770963),
    ('The Java Zone','41 Cole Boulevard','Hartford','CT','06120',41.786052,-72.676708)
GO

insert into websites
    (website_address,website_restaurant_id)
    VALUES
    ('www.bensrestaurants.com',1),
    ('www.danspizza.com',2),
    ('www.mungdaalhealthyeats.com',5),
    ('www.retrocreamery.com',6),
    ('www.javazone.com',7)
GO

insert into restaurants_categories
    (restaurant_id,category_id)
    VALUES
    (1,2),
    (1,7),
    (1,9),
    (2,1),
    (2,9),
    (3,2),
    (3,9),
    (4,5),
    (4,8),
    (5,6),
    (6,4),
    (6,9),
    (7,3),
    (7,9)
GO

insert into restaurants_data_sources
    (restaurant_id,source_id)
    VALUES
    (1,1),
    (1,5),
    (2,1),
    (2,4),
    (3,3),
    (3,4),
    (4,2),
    (5,4),
    (5,5),
    (6,1),
    (6,2),
    (7,5)
GO

insert into restaurants_owners
    (restaurant_id,owner_id)
    VALUES
    (1,1),
    (2,2),
    (3,3),
    (4,4),
    (5,5),
    (6,2),
    (6,1),
    (7,4),
    (7,5)
GO

insert into restaurants_customer_ratings
    (restaurant_id,customer_rating_id)
    VALUES
    (1,1),
    (1,6),
    (1,9),
    (2,4),
    (2,10),
    (2,12),
    (3,5),
    (3,17),
    (3,15),
    (4,7),
    (4,20),
    (4,14),
    (5,18),
    (5,19),
    (6,2),
    (6,3),
    (6,8),
    (7,11),
    (7,13),
    (7,16)
GO

select * from v_restaurants_categories
select * from v_restaurants_customer_ratings
select * from v_restaurants_data_sources
select * from v_restaurants_owners